# -*- coding: utf-8 -*-
"""
Created on Mon Aug 23 11:09:43 2021

@author: Rog
"""
import sklearn.metrics
import math
import sklearn
import pandas as pd
import numpy
from numpy import mean
from numpy import std
from sklearn.datasets import make_classification
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import RepeatedKFold
from sklearn.ensemble import AdaBoostRegressor
'''
df= pd.read_excel ('C:/Users/Rog/Desktop/rbagging.xlsx')
DATA={'LSTM',
      'Bi-LSTM', 'CNN-LSTM'}
X= df[DATA][249:548]
y= df['Station'][249:548]
'''

df= pd.read_excel ('C:/Users/Rog/Desktop/bagg_rand_adab2.xlsx')
DATA={'ECMWF','NCEP','UKMO','LSTM','CNN', 'Bi-LSTM', 'CNN-LSTM','Conv-LSTM','CNN-Bi-LSTM'}
X= df[DATA][361:390]
y= df['Observed'][361:390]


# configure the ensemble model
model = AdaBoostRegressor(n_estimators=10)
model.fit(X, y)
prediction= model.predict(X)
# configure the resampling method
cv = RepeatedKFold(n_splits=9, n_repeats=3, random_state=1)
# evaluate the ensemble on the dataset using the resampling method
n_scores = cross_val_score(model, X, y, scoring='neg_mean_absolute_error', cv=cv, n_jobs=-1)
# report ensemble performance
print('Mean Accuracy: %.3f (%.3f)' % (mean(n_scores), std(n_scores)))
#====================================================================
#test data
x_hat=df[DATA][390:413]
y_real=df['Observed'][390:413]
y_hat= model.predict(x_hat)

#=============================================================
#Statistical_Indices
mse = sklearn. metrics. mean_squared_error(y_real, y_hat)
rmse = math. sqrt(mse)
print('RMSE of test_data is equal to: ', rmse)
r_square = sklearn. metrics.r2_score(y_real, y_hat)
print('R^2 of test_data is equal to: ',r_square)