# -*- coding: utf-8 -*-
"""
Created on Mon Feb 28 19:02:33 2022

@author: Rog
"""

from sklearn import preprocessing
from sklearn import decomposition
from sklearn import pipeline
import sklearn.metrics
import math
import datetime
import pandas as pd
import numpy as np
from numpy import mean
from numpy import std
from sklearn import model_selection
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import RepeatedKFold
from sklearn.ensemble import AdaBoostRegressor
from hyperopt import hp, fmin, Trials, tpe
from hyperopt.pyll.base import scope
from functools import partial

start= datetime.datetime.now() 

def optimize(params,X,y):
    global y_hat
    global y_real
    df= pd.read_excel ('C:/Users/Rog/Desktop/bagg_rand_adab2.xlsx')
    DATA={'LSTM','CNN', 'Bi-LSTM', 'CNN-LSTM', 'Conv-LSTM', 'CNN-Bi-LSTM'}
    AdaBoostRegressor()
    model = AdaBoostRegressor(**params)
    cv = RepeatedKFold(n_splits=9, n_repeats=3, random_state=1)
    accuracies=[]
    X= df[DATA][13:1280]
    y= df['Observed'][13:1280]
    model.fit(X, y)
    x_hat=df[DATA][1280:1295]
    y_real=df['Observed'][1280:1295]
    y_hat= model.predict(x_hat)
    mse = sklearn. metrics. mean_squared_error(y_real, y_hat)
    return mse

if __name__=="__main__":
    df= pd.read_excel ('C:/Users/Rog/Desktop/bagg_rand_adab2.xlsx')
    DATA={'LSTM','CNN', 'Bi-LSTM', 'CNN-LSTM', 'Conv-LSTM', 'CNN-Bi-LSTM'}
    X= df[DATA][13:1280]
    y= df['Observed'][13:1280]
    
    param_space= {
        "n_estimators":scope.int(hp.quniform("n_estimators", 10, 1000,1)),
        "learning_rate":scope.float(hp.quniform("learning_rate", 0.1, 0.5,0.1)),
        "loss":(hp.choice("loss",['linear', 'square', 'exponential']))
                }
    
    optimization_function=partial(optimize,X=X,y=y)
    trials=Trials()
    
    result=fmin(fn=optimization_function,
                space=param_space,
                algo=tpe.suggest,
                max_evals=50,
                trials=trials)
    
    print(result)
    
end= datetime.datetime.now()
elapsed= end-start

print('Total training time:', str(elapsed))
    
