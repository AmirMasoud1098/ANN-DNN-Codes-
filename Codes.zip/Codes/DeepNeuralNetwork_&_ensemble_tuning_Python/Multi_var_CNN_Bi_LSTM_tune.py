# -*- coding: utf-8 -*-
"""
Created on Thu Mar 17 22:34:57 2022

@author: Rog
"""

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM, Flatten,TimeDistributed,Bidirectional
from tensorflow.keras.layers import Conv1D,MaxPooling1D, Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import plot_model
from tensorflow.keras.losses import mse
from tensorflow.keras import callbacks
import matplotlib.pyplot as plt
import numpy as np
from numpy import hstack
import pandas as pd
from numpy import array
import datetime
import sklearn.metrics
import math
import kerastuner as kt

# split a multivariate sequence 
def split_sequences(sequences, n_steps_in, n_steps_out):
	X, y = list(), list()
	for i in range(len(sequences)):
		# find the end of this pattern
		end_ix = i + n_steps_in
		out_end_ix = end_ix + n_steps_out-1
		# check if we are beyond the dataset
		if out_end_ix > len(sequences):
			break
		# gather input and output parts of the pattern
		seq_x, seq_y = sequences[i:end_ix, :-1], sequences[end_ix-1:out_end_ix, -1]
		X.append(seq_x)
		y.append(seq_y)
	return array(X), array(y)
 
#=========================================================================
# Load data
start_test_index=q=14000
end=15300
df= pd.read_excel ('C:/Users/Rog/Desktop/withzeors.xlsx')
temp={'t'}
prev_rain={'rrr-1'}
humidity={'u'}
r_f={'rrr'}
#temp
train_temp= df[temp][0:q]
train_temp=np.array(train_temp)
test_temp=df[temp][q:end]
test_temp=np.array(test_temp)
#previous rainfall
train_prev_rain= df[prev_rain][0:q]
train_prev_rain=np.array(train_prev_rain)
test_prev_rain=df[prev_rain][q:end]
test_prev_rain=np.array(test_prev_rain)
#humidity
train_humidity= df[humidity][0:q]
train_humidity=np.array(train_humidity)
test_humidity=df[humidity][q:end]
test_humidity=np.array(test_humidity)
#forecasting raifall
train_r_f= df[r_f][0:q]
train_r_f=np.array(train_r_f)
test_r_f=df[r_f][q:end]
test_r_f=np.array(test_r_f)

# convert train to [rows, columns] structure
in_seq1 = train_temp.reshape((len(train_temp), 1))
in_seq2 = train_prev_rain.reshape((len(train_prev_rain), 1))
in_seq3 = train_humidity.reshape((len(train_humidity), 1))
out_seq = train_r_f.reshape((len(train_r_f), 1))
# horizontally stack columns
train_dataset = hstack((in_seq1, in_seq2, in_seq3, out_seq))
# convert test to [rows, columns] structure
in_seq11 = test_temp.reshape((len(test_temp), 1))
in_seq21 = test_prev_rain.reshape((len(test_prev_rain), 1))
in_seq31 = test_humidity.reshape((len(test_humidity), 1))
out_seq1 = test_r_f.reshape((len(test_r_f), 1))
# horizontally stack columns
test_dataset = hstack((in_seq11, in_seq21, in_seq31, out_seq1))

n_steps_in = 10
n_steps_out = 1
X, y = split_sequences(train_dataset, n_steps_in, n_steps_out)
p, r = split_sequences(test_dataset, n_steps_in, n_steps_out)
n_features = X.shape[2]
#============================================================
#variables
n_steps_in = 5
n_seq_in = 2
n_steps_out = 1

# reshape from [samples, timesteps] into [samples, timesteps, features]
X = X.reshape((X.shape[0], n_seq_in, n_steps_in, n_features))
p = p.reshape((p.shape[0], n_seq_in, n_steps_in, n_features))

start= datetime.datetime.now()  

def model_builder(hp):
    global hp_batch
    model = Sequential()
    # Tune the number of units in the Dense layer
    hp_n_hidden = hp.Int('units', min_value = 10, max_value = 100, step = 10)
    hp_filters = hp.Int('filters', min_value = 4, max_value = 128, step = 12)
    hp_kernel_size = hp.Choice('kernel_size', values = [1, 2, 4]) 
    hp_learning_rate = hp.Choice('learning_rate', values = [1e-2, 1e-3, 1e-4]) 
    hp_batch = hp.Choice('batch_size', values = [32, 64, 128, 256, 512, 1024, 2048, 4096])
    hp_dropout=hp.Choice('dropout', values = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]) 
    
    model.add(TimeDistributed(Conv1D(filters=hp_filters, kernel_size=hp_kernel_size,
                         activation='tanh'),input_shape=(None, n_steps_in, n_features)))
    model.add(TimeDistributed(Flatten()))
    model.add(Bidirectional(LSTM(hp_n_hidden, activation='tanh',return_sequences=True)))
    model.add(Bidirectional(LSTM(hp_n_hidden, activation='tanh')))
    model.add(Dropout(rate=hp_dropout))

    model.add(Dense(n_steps_out))
    model.compile(loss=mse, optimizer=Adam(learning_rate=hp_learning_rate),
                  metrics=['mean_squared_error'])

    return model

tuner = kt.RandomSearch(model_builder,
                        objective = 'val_mean_squared_error',
                        max_trials = 10,
                        executions_per_trial=1,
                        directory = 'rainfall_randomsearch',
                        project_name = 'Rainfalll_nowcasting') 
'''
tuner=kt.BayesianOptimization(model_builder,objective='loss',max_trials=1,
                              num_initial_points=1)
'''
tuner.search(X, y, epochs=3, batch_size=hp_batch, verbose=0, shuffle=False,
                 validation_data=(p,r), validation_batch_size=hp_batch)

end= datetime.datetime.now()
tuner.results_summary()
# Which was the best model?
best_model = tuner.get_best_models(1)[0]
# What were the best hyperparameters?
best_hyperparameters = tuner.get_best_hyperparameters(1)[0]  
parameters=best_hyperparameters.values

elapsed= end-start
print('Total training time:', str(elapsed))