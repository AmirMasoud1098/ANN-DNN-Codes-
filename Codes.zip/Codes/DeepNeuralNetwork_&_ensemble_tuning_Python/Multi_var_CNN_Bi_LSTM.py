# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 10:53:40 2022

@author: Rog
"""

from numpy import array
from numpy import hstack
from numpy import array
from numpy import hstack
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM, Flatten,TimeDistributed,Bidirectional
from tensorflow.keras.layers import Conv1D,MaxPooling1D, Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import plot_model
import numpy as np
from tensorflow.keras.losses import mse
import pandas as pd
import math
import datetime
import sklearn.metrics
import matplotlib.pyplot as plt

# split a multivariate sequence into samples
def split_sequences(sequences, n_steps_in, n_steps_out):
	X, y = list(), list()
	for i in range(len(sequences)):
		# find the end of this pattern
		end_ix = i + n_steps_in
		out_end_ix = end_ix + n_steps_out-1
		# check if we are beyond the dataset
		if out_end_ix > len(sequences):
			break
		# gather input and output parts of the pattern
		seq_x, seq_y = sequences[i:end_ix, :-1], sequences[end_ix-1:out_end_ix, -1]
		X.append(seq_x)
		y.append(seq_y)
	return array(X), array(y)
 
#=========================================================================
# Load data
start_test_index=q=14000
end=15350
df= pd.read_excel ('C:/Users/Rog/Desktop/withzeors.xlsx')
temp={'t'}
prev_rain={'rrr-1'}
humidity={'u'}
r_f={'rrr'}
#temp
train_temp= df[temp][0:q]
train_temp=np.array(train_temp)
test_temp=df[temp][q:end]
test_temp=np.array(test_temp)
#previous rainfall
train_prev_rain= df[prev_rain][0:q]
train_prev_rain=np.array(train_prev_rain)
test_prev_rain=df[prev_rain][q:end]
test_prev_rain=np.array(test_prev_rain)
#humidity
train_humidity= df[humidity][0:q]
train_humidity=np.array(train_humidity)
test_humidity=df[humidity][q:end]
test_humidity=np.array(test_humidity)
#forecasting raifall
train_r_f= df[r_f][0:q]
train_r_f=np.array(train_r_f)
test_r_f=df[r_f][q:end]
test_r_f=np.array(test_r_f)

# convert train to [rows, columns] structure
in_seq1 = train_temp.reshape((len(train_temp), 1))
in_seq2 = train_prev_rain.reshape((len(train_prev_rain), 1))
in_seq3 = train_humidity.reshape((len(train_humidity), 1))
out_seq = train_r_f.reshape((len(train_r_f), 1))
# horizontally stack columns
train_dataset = hstack((in_seq1, in_seq2, in_seq3, out_seq))
# convert test to [rows, columns] structure
in_seq11 = test_temp.reshape((len(test_temp), 1))
in_seq21 = test_prev_rain.reshape((len(test_prev_rain), 1))
in_seq31 = test_humidity.reshape((len(test_humidity), 1))
out_seq1 = test_r_f.reshape((len(test_r_f), 1))
# horizontally stack columns
test_dataset = hstack((in_seq11, in_seq21, in_seq31, out_seq1))

n_steps_in = 20
n_steps_out = 1
X, y = split_sequences(train_dataset, n_steps_in, n_steps_out)
p, r = split_sequences(test_dataset, n_steps_in, n_steps_out)
n_features = X.shape[2]
#============================================================
#variables
n_steps_in = 10
n_seq_in = 2
n_steps_out = 1
batch_size1 = 2048

# reshape from [samples, timesteps] into [samples, timesteps, features]
X = X.reshape((X.shape[0], n_seq_in, n_steps_in, n_features))
p = p.reshape((p.shape[0], n_seq_in, n_steps_in, n_features))

# ===========================================================
#Model
model = Sequential()
model.add(TimeDistributed(Conv1D(filters=100, kernel_size=4, activation='tanh'),
                          input_shape=(None, n_steps_in, n_features)))
model.add(TimeDistributed(Flatten()))
model.add(Bidirectional(LSTM(50, activation='relu',return_sequences=True)))
model.add(Bidirectional(LSTM(50, activation='relu')))
model.add(Dropout(0.4))
model.add(Dense(n_steps_out))
model.compile(loss=mse, optimizer=Adam(learning_rate=0.001), metrics=['accuracy'])
#===============================================================
#Train
start= datetime.datetime.now()
network_history= model.fit(X, y, epochs=30, batch_size=batch_size1, verbose=0,
                          shuffle=False, validation_split=0.2,
                          validation_batch_size=batch_size1)
end= datetime.datetime.now()
elapsed= end-start
print('Total training time:', str(elapsed))
plot_model(model, to_file='Multi_var_CNNBiLSTM model.pdf', show_shapes=True)
history=network_history.history
#===================================================================
#Test 
predicted_output = model.predict(p, batch_size=batch_size1, verbose=0)
predicted_output=predicted_output[:,0]
r=r[:,0]
predicted_output=predicted_output
for i in range (len(predicted_output)):
    if predicted_output[i]>0.15:
       predicted_output[i]=predicted_output[i]*36
    elif predicted_output[i]<0:
       predicted_output[i]=0
    else:
        predicted_output[i]=predicted_output[i]*26

r=r*26
#================================================================
#Plot

losses=history['loss']
val_losses=history['val_loss']

plt.xlabel('Epochs')
plt.ylabel('loss')
plt.plot(losses)
plt.plot(val_losses)
plt.legend(['loss','val_loss'])
plt.xlim(0, 30)

plt.figure()
plt.xlabel('Epochs')
plt.ylabel('Precipitation(mm)')
plt.plot(r, color= 'green')
plt.plot(predicted_output, color='red')
plt.legend(['Expected','Predicted'])
plt.show()

#=============================================================
#Statistical_Indices
rmse1 = math.sqrt(losses[29])
print('RMSE of train_data is equal to: ', rmse1)
rmse2 = math.sqrt(val_losses[29])
print('RMSE of validation_data is equal to: ', rmse2)
rmse3 = math.sqrt(sklearn. metrics. mean_squared_error(r, predicted_output))
print('RMSE of test_data is equal to: ', rmse3)

s=np.mean(r)
num=((predicted_output-r)**2)
num_sum=np.sum(num)
den=np.sum((r-s)**2)
nse=1-(num_sum/den)
print('NSE of test_data is equal to: ',nse)