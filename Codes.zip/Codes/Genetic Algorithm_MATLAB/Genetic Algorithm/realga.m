clc;
clear;
close all;

%% Problem Definition
tic;
global NFE;
global su;
global S;
global v1;
global v2;
S=0;
v1=0;
v2=0;
su=0;
NFE=0;
CostFunction=@(x) sphere(x);   %costfunction
nvar=72;                       %# of decision variables
varsize=[1 nvar];
varmin=zeros(1,72);
varmax=4000*ones(1,72);
gamma=1;
%% GA Parameters

MaxIt=20;               %Maximum number of iterations
npop=400;                 %popukation size

pc=0.7;                  %crossover percentage
nc=2*round((pc*npop)/2); %number of offsprings(parents);
pm=0.2;                  %mutation percentage
nm=round(pm*npop);       %number of mutants
mu=0.01;                  %mutation rate

beta=5;                  %selection pressure
tournamentsize=3;        %tournament_size
%% Initialization

empty_individual.position=[];
empty_individual.cost=[];

pop=repmat(empty_individual,npop,1);

for i=1:npop
    %initialize position
    pop(i).position=unifrnd(varmin,varmax,varsize);
    %Evaluate
    pop(i).cost=CostFunction(pop(i).position);
end

%sort population
costs=[pop.cost];
[costs,sortorder]=sort(costs);
pop=pop(sortorder);

%store best solution
bestsol=pop(1);

% array to hold best cost values
bestcost=zeros(MaxIt,1);
%store worst cost
worstcost=pop(end).cost;

%array to hold number of function evaluations (NFE)
nfe=zeros(MaxIt,1);
%% Main Loop

for it=1:MaxIt
    
   %calculate selection probabilities
   P=exp(-beta*costs/worstcost);
   P=P/sum(P);
   
    %Crossover
    popc=repmat(empty_individual,nc/2,2);
    for k=1:nc/2
        %select parents
        i1=tournamentselection(pop,tournamentsize);
        i2=tournamentselection(pop,tournamentsize);
        
        %i1=roulettewheelselection(P);
        %i2=roulettewheelselection(P);
        p1=pop(i1);
        p2=pop(i2);
        %crossover
        [popc(k,1).position, popc(k,2).position]=arithmeticcrossover(p1.position,p2.position,gamma,varmin,varmax);
        %evaluate
        popc(k,1).cost=CostFunction(popc(k,1).position);
        popc(k,2).cost=CostFunction(popc(k,2).position);
    end
    popc=popc(:);
    %Mutation
    popm=repmat(empty_individual,nm,1);
    for k=1:nm
        for j=1:nvar
        %select parent
        i=randi([1 npop]);
        p=pop(i);
        %mutation
        popm(k).position=realmutate(p.position,mu,varmin(j),varmax(j));
        %evaluate
        popm(k).cost=CostFunction(popm(k).position);
        end
    end
    
    %Merge
    pop=[pop;popc;popm];
    
    %sort
    costs=[pop.cost];
    [costs, sortorder]=sort(costs);
    pop=pop(sortorder);
    
    %update worst cost
    worstcost=max(worstcost,pop(end).cost);
    
    %truncate
    pop=pop(1:npop);
    costs=costs(1:npop);
    
    %storebestsol
    bestsol(it)=pop(1);
    
    %storebestcosteverfound
    bestcost(it)=bestsol(it).cost;
    
    %store NFE
    nfe(it)=NFE;
    
    %show oteration information
    disp(['iteration' num2str(it) ': NFE' num2str(nfe(it)) ', bestcost=' num2str(bestcost(it))]);
end
toc;
%% Results

figure;
plot(bestcost,'LineWidth',2);
xlabel('Iteration');
ylabel('Costs');









