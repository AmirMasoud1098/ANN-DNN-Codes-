function i=tournamentselection(pop,m)

    npop=numel(pop);
    S=randsample(npop,m);
    spop=pop(S);
    scosts=[spop.cost];
    [~,j]=min(scosts);
    i=S(j);
end