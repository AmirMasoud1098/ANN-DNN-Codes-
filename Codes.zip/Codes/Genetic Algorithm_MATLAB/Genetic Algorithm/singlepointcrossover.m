function [y1,y2]=singlepointcrossover(x1,x2)

    nvar=numel(x1);
    c=randi([1 nvar-1]);
    y1=[x1(1:c) x2(c+1:end)];
    y2=[x2(1:c) x1(c+1:end)];
    
end