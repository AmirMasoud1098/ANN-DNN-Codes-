function y=realmutate(x,mu,varmax,varmin)
    nvar=numel(x);
    nmu=ceil(nvar*mu);
    j=randsample(nvar,nmu);
    y=x;
    sigma=0.1*(varmax-varmin);
    y(j)=x(j)+sigma*randn(size(j));
    
    y=max(y,varmin);
    y=min(y,varmax);
end